## Første versjon med hele json schema lagret i en fil 0.9
Versjon 1.0 er synket med felles schema for begjæring om varetekt samt at alle detaljer er med.
[Versjon 1.0](../1.0/readme.md)