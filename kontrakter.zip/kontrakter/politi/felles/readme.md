# Felles definisjoner til dokumentasjon
Vi har ikke felles skjema da allt er inkludert i hver melding, men samler noen definisjoner her for diskusjon.
person

## Personer og adresser
### Fortrolige adresser
Ved fortrolige adresser så blir det aldri sendt med noen adresser fra BL.
Den er satt til tom for å unngå lekasjer av fortrolige adresser.
(person-fortrolig-adresse.json).

### Strengt fortrolige adresser
Personen blir markert så vi vet at han/hun har en strengt fortrolig adresse.
Adressen er ikke hemmelig i seg selv da det er en postboks adresse.
hmmm. vi kan dele den adressen, men det må tas hensy (hvilke hensyn ?).
(person-strengtfortrolig-adresse.json)

### Klient adresse
Kommer, vi har ikke håndtering av denne foreløpig.
Regner med at denne kan deles med Domstol, Kriminalomsorgen.
Har laget et forslag der det kanskje blir slikt.
(person-klient-adresse.json)

### Folkeregister eksempler
Se katalogen freg-eksempler
